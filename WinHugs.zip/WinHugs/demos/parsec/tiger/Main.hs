{---------------------------------------------------------------
Daan Leijen (c) 2001.  daan@cs.uu.nl

$Revision: 1.1 $
$Author: ross $
$Date: 2003/07/31 17:45:35 $
---------------------------------------------------------------}
module Main where

import Tiger( prettyTigerFromFile )

main  = prettyTigerFromFile "fac.tig"
