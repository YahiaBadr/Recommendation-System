module LazyST(
	module Data.STRef.Lazy,
	module Control.Monad.ST.Lazy,
	module Hugs.LazyST,
    ) where

import Data.STRef.Lazy
import Control.Monad.ST.Lazy
import Hugs.LazyST
