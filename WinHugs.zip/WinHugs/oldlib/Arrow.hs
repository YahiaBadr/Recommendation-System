module Arrow
  {-# DEPRECATED "This library will go away soon; use Control.Arrow instead" #-} 
  (module Control.Arrow) where
import Control.Arrow
