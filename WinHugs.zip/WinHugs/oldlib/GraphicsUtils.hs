module GraphicsUtils(
	module Graphics.HGL,
    ) where

import Graphics.HGL
