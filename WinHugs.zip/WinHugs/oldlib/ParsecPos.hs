module ParsecPos
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Pos" #-}
(module Text.ParserCombinators.Parsec.Pos) where
import Text.ParserCombinators.Parsec.Pos
