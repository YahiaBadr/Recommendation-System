module ParsecLanguage
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Language" #-}
(module Text.ParserCombinators.Parsec.Language) where
import Text.ParserCombinators.Parsec.Language
