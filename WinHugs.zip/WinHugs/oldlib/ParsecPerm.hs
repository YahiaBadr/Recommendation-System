module ParsecPerm
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Perm" #-}
(module Text.ParserCombinators.Parsec.Perm) where
import Text.ParserCombinators.Parsec.Perm
