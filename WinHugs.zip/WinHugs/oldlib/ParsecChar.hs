module ParsecChar
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Char" #-}
(module Text.ParserCombinators.Parsec.Char) where
import Text.ParserCombinators.Parsec.Char
