module BSD
{-# DEPRECATED "This module has moved to Network.BSD" #-}
(module Network.BSD) where
import Network.BSD
