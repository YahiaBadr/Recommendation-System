module HsParser
{-# DEPRECATED "This module has moved to Language.Haskell.Parser" #-}
(module Language.Haskell.Parser) where
import Language.Haskell.Parser
