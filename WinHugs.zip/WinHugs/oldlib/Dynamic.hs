module Dynamic
  {-# DEPRECATED "This library has moved to Data.Dynamic" #-} 
  (module Data.Dynamic) where
import Data.Dynamic

