module QuickCheckUtils
{-# DEPRECATED "This module has moved to Debug.QuickCheck.Utils" #-}
(module Debug.QuickCheck.Utils) where
import Debug.QuickCheck.Utils
