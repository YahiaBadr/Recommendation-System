module IORef
  {-# DEPRECATED "This module has moved to Data.IORef" #-} 
  (module Data.IORef) where
import Data.IORef
