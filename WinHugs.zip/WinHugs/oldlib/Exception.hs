module Exception
  {-# DEPRECATED "This library has moved to Control.Exception" #-} 
  (module Control.Exception) where
import Control.Exception
