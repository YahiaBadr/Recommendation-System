module ParsecToken
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Token" #-}
(module Text.ParserCombinators.Parsec.Token) where
import Text.ParserCombinators.Parsec.Token
