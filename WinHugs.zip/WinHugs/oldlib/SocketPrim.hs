module SocketPrim
{-# DEPRECATED "This module has moved to Network.Socket" #-}
(module Network.Socket) where
import Network.Socket
