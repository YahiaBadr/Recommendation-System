module Observe(
	module Hugs.Observe,
    ) where

import Hugs.Observe
