module Memo(
	module Hugs.Memo,
    ) where

import Hugs.Memo
