module Parsec
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec" #-}
(module Text.ParserCombinators.Parsec) where
import Text.ParserCombinators.Parsec
