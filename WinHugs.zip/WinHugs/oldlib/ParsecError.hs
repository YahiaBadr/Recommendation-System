module ParsecError
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Error" #-}
(module Text.ParserCombinators.Parsec.Error) where
import Text.ParserCombinators.Parsec.Error
