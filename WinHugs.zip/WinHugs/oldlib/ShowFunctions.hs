module ShowFunctions
  {-# DEPRECATED "See Text.Show.Functions" #-} 
  (module Text.Show.Functions) where
import Text.Show.Functions
