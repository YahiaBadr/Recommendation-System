module QuickCheck
{-# DEPRECATED "This module has moved to Debug.QuickCheck" #-}
(module Debug.QuickCheck) where
import Debug.QuickCheck
