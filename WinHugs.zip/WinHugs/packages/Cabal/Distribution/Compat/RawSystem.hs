{-# OPTIONS_GHC -cpp #-}
-- #hide
module Distribution.Compat.RawSystem (rawSystem) where






import System.Cmd (rawSystem)







