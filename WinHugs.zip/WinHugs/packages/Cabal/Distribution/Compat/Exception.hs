{-# OPTIONS_GHC -cpp #-}
-- #hide
module Distribution.Compat.Exception (bracket,finally) where





import Control.Exception (bracket,finally)






