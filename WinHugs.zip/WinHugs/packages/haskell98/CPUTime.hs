module CPUTime (
    getCPUTime, cpuTimePrecision 
  ) where

import System.CPUTime
