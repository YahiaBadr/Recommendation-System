module Ratio (
    Ratio, Rational, (%), numerator, denominator, approxRational
  ) where

import Data.Ratio
