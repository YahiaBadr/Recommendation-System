module CError (module Foreign.C.Error) where
import Foreign.C.Error
