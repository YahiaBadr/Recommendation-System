module MarshalAlloc (module Foreign.Marshal.Alloc) where
import Foreign.Marshal.Alloc
