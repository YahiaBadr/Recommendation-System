module Word ( module Data.Word ) where
import Data.Word
