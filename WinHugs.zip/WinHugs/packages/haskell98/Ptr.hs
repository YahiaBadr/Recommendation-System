module Ptr (module Foreign.Ptr) where
import Foreign.Ptr
