module MarshalArray (module Foreign.Marshal.Array) where
import Foreign.Marshal.Array
