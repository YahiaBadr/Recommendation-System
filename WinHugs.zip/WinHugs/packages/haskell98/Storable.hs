module Storable (module Foreign.Storable) where
import Foreign.Storable
