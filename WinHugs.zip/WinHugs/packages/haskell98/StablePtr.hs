module StablePtr (module Foreign.StablePtr) where
import Foreign.StablePtr
