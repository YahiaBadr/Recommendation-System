module ForeignPtr (module Foreign.ForeignPtr) where
import Foreign.ForeignPtr
