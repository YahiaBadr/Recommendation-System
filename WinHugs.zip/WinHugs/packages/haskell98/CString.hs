module CString (module Foreign.C.String) where
import Foreign.C.String
